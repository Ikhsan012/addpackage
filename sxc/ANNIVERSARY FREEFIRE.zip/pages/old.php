			<div class="item">
                <img src="assets/old/1.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/2.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/3.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/4.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/5.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/6.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/7.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/1.jpeg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/2.jpeg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/3.jpeg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/4.jpeg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/old/5.jpeg">
                <div class="click">Claim</div>
            </div>
			<div class="item">
                <img src="assets/evo/1.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/2.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/3.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/4.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/5.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/6.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/7.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/8.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/9.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/10.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/11.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/evo/12.jpg">
                <div class="click">Claim</div>
            </div>
			<div class="item">
                <img src="assets/incu/1.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/2.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/3.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/4.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/5.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/6.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/7.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/8.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/9.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/10.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/11.jpg">
                <div class="click">Claim</div>
            </div>
            <div class="item">
                <img src="assets/incu/12.jpg">
                <div class="click">Claim</div>
            </div>